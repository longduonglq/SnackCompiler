x: str = ""
i: int = 0

x = input()

while i < len(x):
    print(x[i])
    i = i + 1

print("len of input is")
print(len(x))