
s:str = ""
char:str = ""
i:int = 0
s = input()

while i < len(s):
    char = s[i]
    i = i + 1
    print(char)
