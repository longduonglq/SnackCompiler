length:int = 0
input_str:str = ""
input_str = input()

while length < len(input_str):
    length = length + 1

print(length)