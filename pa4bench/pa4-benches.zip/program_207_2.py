def f() -> int:
    print("start f")
    g()
    print("end f")
    return 42


def g() -> object:
    print("start g")
    h()
    print("end g")

def h() -> object:
    print("start h")
    print("end h")


s: str = ""
a:int = 1
b1:int = 2
b2:int = 2
b3:int = 2
b4:int = 2
b5:int = 2
b6:int = 2
b7:int = 2
b8:int = 2
b9:int = 2
b10:int = 2
b11:int = 2
b12:int = 2
b13:int = 2
b14:int = 2
b15:int = 2
b16:int = 2
b17:int = 2
b18:int = 2
b19:int = 2
b1 = 2 + a
b2 = 2 + b1
b3 = 2 + b2
b4 = 2 + b3
b5 = 2 + b4
b6 = 2 + b5
b7 = 2 + b6
b8 = 2 + b7
b9 = 2 + b8
b10 = 2 + b9
b11 = 2 + b10
b12 = 2 + b11
b13 = 2 + b12
b14 = 2 +b13
b15 = 2 + b14
b16 = 2 + b15
b17 = 2 + b16
b18 = 2 + b17
b19 = 2 + b18
s = input()
while len(s) > 0:
    print(f())
    print(1 + 1 + 1 + 1 + 1 + b19)
    print(b19)
    s = input()
    print(s)