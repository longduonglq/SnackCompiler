a:str = ""
c:str = ""
b:int = 0
d:str = "a"
a = input()

while b < len(a):
    c = a[b]
    if (c == d):
        print(c)
    b = b + 1