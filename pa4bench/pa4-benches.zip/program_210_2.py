a:str = ""
c:str = ""
b:int = 0
a = input()

while b < len(a):
    c = a[b]
    print(c)
    b = b + 1