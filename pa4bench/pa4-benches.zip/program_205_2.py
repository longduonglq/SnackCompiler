def f()->object:
    a:str = "b"
    c:int = 6
    print(a)
    return c

# # aaa = A()
# # aaa.add(2,3)
# # # aaa.sa = 3
# # # bbb = B()
# # # bbb.saa = 2
# #
# #
# #
# # # print(bb + "hhh")
# # # add(5,10)
# #
# # Test of 'input' function.
# # def add(a:int, b:int):
# #         print(a+b)
# # Binary-search trees
# class TreeNode(object):
# 	value:int = 0
# 	left:"TreeNode" = None
# 	right:"TreeNode" = None
#
# 	def insert(self:"TreeNode", x:int) -> bool:
# 		if x < self.value:
# 			if self.left is None:
# 				self.left = makeNode(x)
# 				return True
# 			else:
# 				return self.left.insert(x)
# 		elif x > self.value:
# 			if self.right is None:
# 				self.right = makeNode(x)
# 				return True
# 			else:
# 				return self.right.insert(x)
# 		return False
#
# 	def contains(self:"TreeNode", x:int) -> bool:
# 		if x < self.value:
# 			if self.left is None:
# 				return False
# 			else:
# 				return self.left.contains(x)
# 		elif x > self.value:
# 			if self.right is None:
# 				return False
# 			else:
# 				return self.right.contains(x)
# 		else:
# 			return True
#
# class Tree(object):
# 	root:TreeNode = None
# 	size:int = 0
#
# 	def insert(self:"Tree", x:int) -> object:
# 		if self.root is None:
# 			self.root = makeNode(x)
# 			self.size = 1
# 		else:
# 			if self.root.insert(x):
# 				self.size = self.size + 1
#
# 	def contains(self:"Tree", x:int) -> bool:
# 		if self.root is None:
# 			return False
# 		else:
# 			return self.root.contains(x)
#
# def makeNode(x: int) -> TreeNode:
# 	b:TreeNode = None
# 	b = TreeNode()
# 	b.value = x
# 	return b
#
#
# # Input parameters
# n:int = 100
# c:int = 4
#
# # Data
# t:Tree = None
# i:int = 0
# k:int = 37813
#
# # Crunch
# t = Tree()
# while i < n:
# 	t.insert(k)
# 	k = (k * 37813) % 37831
# 	if i % c != 0:
# 		t.insert(i)
# 	i = i + 1
#
# print(t.size)
#
# for i in [4, 8, 15, 16, 23, 42]:
# 	if t.contains(i):
# 		print(i)
#

s: str = ""
bb:str = "aaa"
boolb:bool = False
x:int = 0
y:int = 2
a:int = 1
b1:int = 2
b2:int = 2
b3:int = 2
b4:int = 2
b5:int = 2
b6:int = 2
b7:int = 2
b8:int = 2
b9:int = 2
b10:int = 2
b11:int = 2
b12:int = 2
b13:int = 2
b14:int = 2
b15:int = 2
b16:int = 2
b17:int = 2
b18:int = 2
b19:int = 2
b1 = 2 + a
b2 = 2 + b1
b3 = 2 + b2
b4 = 2 + b3
b5 = 2 + b4
b6 = 2 + b5
b7 = 2 + b6
b8 = 2 + b7
b9 = 2 + b8
b10 = 2 + b9
b11 = 2 + b10
b12 = 2 + b11
b13 = 2 + b12
b14 = 2 +b13
b15 = 2 + b14
b16 = 2 + b15
b17 = 2 + b16
b18 = 2 + b17
b19 = 2 + b18
s = input()
x = y = 42
while len(s) > 0:

    print(x)
    print(s)
    print(b19)
    s = input()
