s: str = ""

s = input()
while len(s) > 0:
    print(s[0] == s[1])
    s = input()