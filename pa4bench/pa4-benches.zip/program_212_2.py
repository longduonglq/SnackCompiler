a:str = ""
c:str = ""
b:int = 0
d:str = "a"
e:str = ""
a = input()
e = input()

while b < len(a):
    c = a[b]
    if (c == e[0]):
        print(b)
    b = b + 1