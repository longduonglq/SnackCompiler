s:str = ""
i:int = 0
s = input()
i = len(s) - 1
while i > 0:
    print(s[i])
    i = i - 1