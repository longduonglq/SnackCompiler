inp:str = ""
n:int = 0
x:str = ""

def f(x:str) -> str:
    return x

inp = input()

while inp[n] != "0":
    n = n + 1

    inp[0]
    inp[0]
    inp[0]
    f(inp[n])
    x = f(inp[n])


print(n)