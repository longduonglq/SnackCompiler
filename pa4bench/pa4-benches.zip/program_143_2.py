x: int = 10000000
input_str: str = ""
input_str = input()
x = 0
print("ALWAYS PRINT")
print("EVERY 3")

while x < len(input_str):
    print(x)
    x = x + 3


