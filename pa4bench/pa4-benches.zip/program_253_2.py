s: str = ""

s = input()
while len(s) > 1:
    print(s)
    s = input()
