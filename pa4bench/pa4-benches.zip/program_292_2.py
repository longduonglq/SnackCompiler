s: str = ""

s = input()
while len(s) > 0:
    print(s[2] != s[3])
    s = input()