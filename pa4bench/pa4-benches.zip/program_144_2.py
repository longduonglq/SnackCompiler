input_str: str = ""
i:int = 0

input_str = input()

while i < len(input_str):
    print(input_str[i])
    i = i + 2

