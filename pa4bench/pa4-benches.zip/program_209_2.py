a:str = ""
b:int = 0
a = input()

while b < len(a):
    print(b)
    b= b + 1
