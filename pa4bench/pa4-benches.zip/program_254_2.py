s: str = ""

s = input()
while len(s) > 1:
    print(s)
    print(s)
    print(len(s))
    s = input()
