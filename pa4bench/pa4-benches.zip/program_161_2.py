x:str = ""
y:str = ""
counter:int = 0

x = input()
counter = 0
while counter < len(x):
  y = x[counter]
  print(y)
  counter = counter + 1


